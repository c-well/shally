/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.17-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: shalom_app
-- ------------------------------------------------------
-- Server version	10.11.17-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bulletin_lines`
--

DROP TABLE IF EXISTS `bulletin_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulletin_lines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bulletin_id` bigint(20) unsigned NOT NULL,
  `section` varchar(255) DEFAULT NULL,
  `part` varchar(255) DEFAULT NULL,
  `person` varchar(255) DEFAULT NULL,
  `kind` varchar(32) NOT NULL DEFAULT 'line',
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bulletin_lines_bulletin_id_sort_order_index` (`bulletin_id`,`sort_order`),
  CONSTRAINT `bulletin_lines_bulletin_id_foreign` FOREIGN KEY (`bulletin_id`) REFERENCES `bulletins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=383 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulletin_lines`
--

LOCK TABLES `bulletin_lines` WRITE;
/*!40000 ALTER TABLE `bulletin_lines` DISABLE KEYS */;
INSERT INTO `bulletin_lines` VALUES
(1,4,NULL,'Call to Worship','Elder Collis Glasgow','line',0,'2026-04-18 20:25:49','2026-04-19 20:02:36',NULL),
(2,4,NULL,'Response Song','Praise Team','line',2,'2026-04-18 20:25:49','2026-04-19 20:02:36',NULL),
(3,4,NULL,'Invocation','Pastor Jermy Arnold','line',3,'2026-04-18 20:25:49','2026-04-19 20:02:36',NULL),
(4,4,NULL,'Announcements','Clerk','line',5,'2026-04-18 20:25:49','2026-04-19 20:02:36',NULL),
(5,4,'Pastoral Greetings / Baby Dedication',NULL,NULL,'section_header',6,'2026-04-18 20:25:49','2026-04-19 21:08:14',NULL),
(6,4,'Pastoral Greetings / Baby Dedication','Welcome','Elder Collis Glasgow','line',4,'2026-04-18 20:25:49','2026-04-19 20:02:36',NULL),
(7,4,'Pastoral Greetings / Baby Dedication','Opening Hymn','#15 My Maker and My King','line',7,'2026-04-18 20:25:49','2026-04-19 20:02:36',NULL),
(8,4,'Pastoral Greetings / Baby Dedication','Intercessory Prayer','Sis Miriam Clarke','line',8,'2026-04-18 20:25:49','2026-04-19 20:02:36',NULL),
(9,4,'Pastoral Greetings / Baby Dedication','Sermon','Pastor Jermy Arnold','line',9,'2026-04-18 20:25:49','2026-04-19 20:02:36',NULL),
(10,4,'Pastoral Greetings / Baby Dedication','Closing Hymn','#250 O for a Thousand Tongues to Sing','line',10,'2026-04-18 20:25:49','2026-04-19 20:02:36',NULL),
(24,4,NULL,'Into','Sis Miriam Clarke','line',1,'2026-04-19 17:10:38','2026-04-19 20:02:36',NULL),
(25,4,NULL,NULL,NULL,'line',12,'2026-04-19 17:11:12','2026-04-19 20:02:36',NULL),
(26,4,'Andre',NULL,NULL,'section_header',11,'2026-04-19 17:11:15','2026-04-19 21:08:27',NULL),
(262,7,NULL,'Call to Worship','Sis. Stacey Brown','line',0,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(263,7,NULL,'Response Song','Praise Team','line',1,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(264,7,NULL,'Invocation','Elder Collis Glasgow','line',2,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(265,7,NULL,'Announcements','Clerk','line',3,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(266,7,'Pastoral Greetings',NULL,NULL,'section_header',4,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(267,7,'Pastoral Greetings / Baby Dedication','Welcome',NULL,'line',5,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(268,7,'Pastoral Greetings / Baby Dedication','Opening Hymn','Priaise Team','line',6,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(269,7,'Pastoral Greetings / Baby Dedication','Scripture Reading','Sis. Darielle Douglas','line',10,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(270,7,'Pastoral Greetings / Baby Dedication','Intercessory Prayer','Sis Juanita Bailey','line',7,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(271,7,'Pastoral Greetings / Baby Dedication','Children\'s Story','Children\'s Ministry','line',8,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(272,7,'Pastoral Greetings / Baby Dedication','Special Music',NULL,'line',10,'2026-04-20 16:34:37','2026-05-02 08:27:46','2026-05-02 08:27:46'),
(273,7,'Pastoral Greetings / Baby Dedication','Sermon','Elder Collis Glasgow','line',12,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(274,7,'Pastoral Greetings / Baby Dedication','Closing Hymn','Praise Team','line',13,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(275,7,'Pastoral Greetings / Baby Dedication','Benediction','Sis. Stacy Brown','line',14,'2026-04-20 16:34:37','2026-05-02 10:08:17',NULL),
(276,8,NULL,'Call to Worship','Elder Derrick Clarke','line',0,'2026-04-20 16:35:09','2026-05-15 17:23:42',NULL),
(277,8,NULL,'Response Song','Praise team','line',1,'2026-04-20 16:35:09','2026-05-08 20:28:18',NULL),
(278,8,NULL,'Invocation','Pastor Kumal Smith','line',2,'2026-04-20 16:35:09','2026-05-15 17:24:44',NULL),
(279,8,NULL,'Announcements','Clerk','line',3,'2026-04-20 16:35:09','2026-05-08 20:28:18',NULL),
(280,8,'Pastoral Greetings',NULL,NULL,'section_header',4,'2026-04-20 16:35:09','2026-05-08 20:28:18',NULL),
(281,8,'Pastoral Greetings / Baby Dedication','Welcome','Sis. Kebrina Stephenson','line',5,'2026-04-20 16:35:09','2026-05-15 17:26:30',NULL),
(282,8,'Pastoral Greetings / Baby Dedication','Opening Hymn','#240 Fairest Lord Jesus','line',6,'2026-04-20 16:35:09','2026-05-08 21:17:02',NULL),
(283,8,'Pastoral Greetings / Baby Dedication','Scripture Reading','Jeremiah Williams','line',13,'2026-04-20 16:35:09','2026-05-08 20:28:18',NULL),
(284,8,'Pastoral Greetings / Baby Dedication','Intercessory Prayer','Elder Maple Mcfarlane','line',8,'2026-04-20 16:35:09','2026-05-08 20:28:18',NULL),
(285,8,'Pastoral Greetings / Baby Dedication','Children\'s Story','Children\'s Ministry','line',10,'2026-04-20 16:35:09','2026-05-08 20:28:18',NULL),
(286,8,'Pastoral Greetings / Baby Dedication','Meditation Song','Anthony Stewart','line',15,'2026-04-20 16:35:09','2026-05-08 20:28:18',NULL),
(287,8,'Pastoral Greetings / Baby Dedication','Sermon','Pastor Kevin Brown','line',16,'2026-04-20 16:35:09','2026-05-08 20:28:18',NULL),
(288,8,'Pastoral Greetings / Baby Dedication','Closing Hymn','#522 My Hope is Built On Nothing Less','line',17,'2026-04-20 16:35:09','2026-05-08 20:28:18',NULL),
(289,8,'Pastoral Greetings / Baby Dedication','Benediction','Elder Troy Boddie','line',18,'2026-04-20 16:35:09','2026-05-08 20:28:18',NULL),
(291,8,'Hymn','#5 All My Hope on God Is Founded',NULL,'line',18,'2026-04-21 22:12:04','2026-05-08 20:28:01','2026-05-08 20:28:01'),
(299,6,NULL,'Call to Worship','Sis. Judith Wallace','line',0,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(300,6,NULL,'Response Song','Bless the Lord oh my soul','line',1,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(301,6,NULL,'Invocation','Bro. Dennis Williams','line',2,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(302,6,'Pastoral Greetings / Baby Dedication','Welcome','Elder David  Stewart','line',3,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(303,6,NULL,'Announcements','Clerk','line',4,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(304,6,'Pastoral Greetings',NULL,NULL,'section_header',5,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(305,6,'Pastoral Greetings / Baby Dedication','Opening Hymn','#286 Wonderful Words of Life','line',6,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(306,6,'Pastoral Greetings / Baby Dedication','Intercessory Prayer','Sis. Nickesha Marshall','line',7,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(307,6,NULL,'Praise and Worship','Praise Team','line',8,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(308,6,NULL,'Children Story','Children\'s Ministry','line',9,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(309,6,NULL,'Offertory','Elder David Stewart','line',10,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(310,6,NULL,'Scripture Reading','Sis. Amira Bennett','line',11,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(311,6,'Pastoral Greetings / Baby Dedication','Sermon','Dennis Williams','line',14,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(312,6,'“There\'s Something About the Word”',NULL,NULL,'section_header',15,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(313,6,'Pastoral Greetings / Baby Dedication','Closing Hymn','#590 Trust and Obey','line',16,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(314,6,NULL,'Benediction','Sis Judith Wallace','line',17,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(315,6,'2 Timothy 3:16-17',NULL,NULL,'section_header',12,'2026-04-25 05:59:52','2026-04-25 11:42:49',NULL),
(316,6,NULL,'Meditation Song','Sis Ariana Bennett','line',13,'2026-04-25 06:00:07','2026-04-25 11:42:49',NULL),
(317,7,NULL,'Offertory','Bro. Ayan Bennett','line',9,'2026-05-02 08:27:00','2026-05-02 10:08:17',NULL),
(318,7,NULL,NULL,NULL,'section_header',11,'2026-05-02 08:27:53','2026-05-02 10:00:26','2026-05-02 10:00:26'),
(319,7,NULL,'Jeremiah 1:4-20; 20:7-9',NULL,'line',11,'2026-05-02 10:00:47','2026-05-02 10:08:17',NULL),
(320,8,'New section',NULL,NULL,'section_header',7,'2026-05-08 20:15:53','2026-05-08 20:29:19','2026-05-08 20:29:19'),
(321,8,NULL,'Praise & Worship','Praise Team','line',9,'2026-05-08 20:18:10','2026-05-08 20:28:18',NULL),
(322,8,NULL,'Offertory','Shana-Gay Morrison','line',11,'2026-05-08 20:19:16','2026-05-08 20:28:18',NULL),
(323,8,'Pastoral Greetings / Baby Dedication',NULL,NULL,'section_header',12,'2026-05-08 20:19:59','2026-05-08 20:28:18',NULL),
(324,8,'Sermon',NULL,NULL,'section_header',19,'2026-05-08 20:23:30','2026-05-08 20:28:06','2026-05-08 20:28:06'),
(325,8,NULL,NULL,NULL,'section_header',20,'2026-05-08 20:25:33','2026-05-08 20:28:10','2026-05-08 20:28:10'),
(326,8,NULL,NULL,'Genesis 25:21-26','line',14,'2026-05-08 20:28:14','2026-05-08 20:28:44',NULL),
(327,27,NULL,'Call to Worship','Elder Derrick Clarke','line',0,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(328,27,NULL,'Response Song','Praise team','line',1,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(329,27,NULL,'Invocation','Pastor Kumal Smith','line',2,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(330,27,NULL,'Announcements','Clerk','line',3,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(331,27,'Pastoral Greetings',NULL,NULL,'section_header',4,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(332,27,'Pastoral Greetings','Welcome','Sis. Kebrina Stephenson','line',5,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(333,27,'Pastoral Greetings','Opening Hymn','Praise team','line',6,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(334,27,'Pastoral Greetings','Intercessory Prayer','Sis Miriam Clarke','line',7,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(335,27,NULL,'Praise & Worship','Praise team','line',8,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(336,27,'Pastoral Greetings','Children\'s Story','Children\'s Ministry','line',9,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(337,27,NULL,'Offertory','Sis Keri-Ann Genus','line',10,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(338,27,'Pastoral Greetings / Baby Dedication',NULL,NULL,'section_header',11,'2026-05-15 19:42:47','2026-05-15 20:07:21','2026-05-15 20:07:21'),
(339,27,'Pastoral Greetings','Scripture Reading','Sis Laylah Brown','line',11,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(340,27,NULL,NULL,'1 Peter 5: 5 - 8','line',13,'2026-05-15 19:42:47','2026-05-16 08:55:26',NULL),
(341,27,'Pastoral Greetings','Meditation Song','Praise team','line',14,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(342,27,'Pastoral Greetings','Sermon','Pastor Kumal Smith','line',15,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(343,27,'Pastoral Greetings','Closing Hymn','Praise team','line',17,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(344,27,'Pastoral Greetings','Benediction','Elder Derrick Clarke','line',18,'2026-05-15 19:42:47','2026-05-16 08:54:46',NULL),
(345,27,'Mission Story',NULL,NULL,'section_header',17,'2026-05-15 20:21:34','2026-05-16 07:12:03','2026-05-16 07:12:03'),
(346,27,'Sermon',NULL,NULL,'section_header',16,'2026-05-16 07:19:20','2026-05-16 08:54:46',NULL),
(347,27,NULL,NULL,NULL,'section_header',12,'2026-05-16 08:52:53','2026-05-16 08:55:10','2026-05-16 08:55:10'),
(348,27,'New section',NULL,NULL,'section_header',19,'2026-05-16 08:54:34','2026-05-16 08:54:40','2026-05-16 08:54:40'),
(349,27,NULL,NULL,NULL,'line',19,'2026-05-16 08:57:21','2026-05-16 08:57:30','2026-05-16 08:57:30'),
(350,27,'Sermon',NULL,NULL,'section_header',19,'2026-05-16 08:57:33','2026-05-16 08:59:39','2026-05-16 08:59:39'),
(351,28,NULL,'Call to Worship','Brother Joshua Stephenson','line',1,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(352,28,NULL,'Response Song','Praise Team','line',2,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(353,28,NULL,'Invocation',NULL,'line',3,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(354,28,NULL,'Announcements','Sis Patricia Chaplin','line',4,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(355,28,'Pastoral Greetings',NULL,NULL,'section_header',5,'2026-05-21 02:57:48','2026-05-22 22:21:33','2026-05-22 22:21:33'),
(356,28,'Pastoral Greetings','Welcome','Amira & Leah','line',5,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(357,28,'Pastoral Greetings','Opening Hymn','#515 \"The Lord is My Light\"','line',7,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(358,28,'Pastoral Greetings','Intercessory Prayer','Brother Jeremiah Williams & Sis Lana','line',8,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(359,28,NULL,'Praise & Worship','Praise Team','line',9,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(360,28,'Pastoral Greetings','Children\'s Story','Sis Remona Dawkins-Somers','line',11,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(361,28,NULL,'Offertory','Sis Leah Brown','line',12,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(362,28,'Pastoral Greetings','Scripture Reading','Sisters Laila & Belinda','line',13,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(363,28,NULL,'Special','Little Dancers','line',6,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(364,28,'Pastoral Greetings','Meditation Song','Praise Team','line',15,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(365,28,'Pastoral Greetings','Sermon #1','Sis Semona Somers','line',18,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(366,28,'Sermon',NULL,NULL,'section_header',16,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(367,28,'Pastoral Greetings','Closing Hymn','#218 \"When He Cometh\"','line',27,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(368,28,'Pastoral Greetings','Benediction','Sis Keyashia Allison','line',29,'2026-05-21 02:57:48','2026-05-22 22:39:50',NULL),
(369,28,NULL,NULL,NULL,'section_header',18,'2026-05-21 03:00:02','2026-05-21 03:04:57','2026-05-21 03:04:57'),
(370,28,'New section',NULL,NULL,'section_header',0,'2026-05-21 03:00:39','2026-05-22 22:39:50',NULL),
(371,28,NULL,NULL,NULL,'line',14,'2026-05-22 22:22:32','2026-05-22 22:39:50',NULL),
(372,28,NULL,'Special Music','Sis Darielle Douglas','line',10,'2026-05-22 22:24:28','2026-05-22 22:39:50',NULL),
(373,28,NULL,'Introduction of Speaker #1','B','line',17,'2026-05-22 22:29:31','2026-05-22 22:39:50',NULL),
(374,28,NULL,'Introduction of Speaker # 2','Sis Jazelle Bennett','line',19,'2026-05-22 22:33:06','2026-05-22 22:39:50',NULL),
(375,28,NULL,'Sermon #3','Sis Ariana Bennett','line',20,'2026-05-22 22:33:18','2026-05-22 22:39:50',NULL),
(376,28,NULL,'Introduction of Speaker # 3','Sis Keziah','line',21,'2026-05-22 22:33:23','2026-05-22 22:39:50',NULL),
(377,28,NULL,'Sermon #3','Shana-Gay Morrison','line',22,'2026-05-22 22:33:28','2026-05-22 22:39:50',NULL),
(378,28,NULL,'Introduction of Speaker #4','Sis Jadoura D. James','line',23,'2026-05-22 22:33:47','2026-05-22 22:39:50',NULL),
(379,28,NULL,'Sermon #4','Anthony Stewart','line',24,'2026-05-22 22:33:55','2026-05-22 22:39:50',NULL),
(380,28,NULL,'Special','Little Dancers','line',26,'2026-05-22 22:38:10','2026-05-22 22:39:50',NULL),
(381,28,'Special Music',NULL,NULL,'section_header',25,'2026-05-22 22:38:56','2026-05-22 22:39:50',NULL),
(382,28,'Benediction',NULL,NULL,'section_header',28,'2026-05-22 22:39:47','2026-05-22 22:39:59',NULL);
/*!40000 ALTER TABLE `bulletin_lines` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-23 18:40:44
